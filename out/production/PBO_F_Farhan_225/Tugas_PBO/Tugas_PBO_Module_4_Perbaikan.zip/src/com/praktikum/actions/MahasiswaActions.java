package Tugas_PBO.src.com.praktikum.actions;

public interface MahasiswaActions {
    void reportItem();
    void viewReportedItems();
}


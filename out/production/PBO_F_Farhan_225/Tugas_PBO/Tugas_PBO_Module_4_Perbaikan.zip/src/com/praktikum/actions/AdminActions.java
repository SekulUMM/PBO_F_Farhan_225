package Tugas_PBO.src.com.praktikum.actions;

public interface AdminActions {
    void manageItems();
    void manageUsers();
}

